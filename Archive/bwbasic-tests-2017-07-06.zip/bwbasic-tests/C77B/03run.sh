# run BIZMII
cp ./DATA/* .
~/bwbasic --tape BIZMII.INP --profile C77.PRO BIZMII.BAS
