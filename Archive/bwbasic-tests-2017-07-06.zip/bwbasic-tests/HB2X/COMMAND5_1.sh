~/bwbasic -p HB2.PRO -p COMMAND5_1.PRO COMMAND5_1.BAS p1 p2 p3 p4 p5 p6 p7 p8 p9
