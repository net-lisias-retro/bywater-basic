
This directory contains most of the tests from the following reference:
------------------------------------------------------------------
The BASIC Handbook: Encyclopedia of the BASIC Computer Language
	by David A. Lien
	1st Edition
	(c) 1978, Compusoft Publishing
	ISBN 0-932760-00-7
	364 pages
------------------------------------------------------------------
Some programs were adapted for Bywater BASIC by Howard Wulf, AF5NE.
------------------------------------------------------------------
EOF
