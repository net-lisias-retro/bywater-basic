These programs are provided solely for amusement.
They are NOT part of regression testing and there is NO support.

Changes made:
a) add missing semicolon/comma in PRINT statements
b) change array names so they were not identical to scalar variable names
c) add spaces around reserved words
d) CASSETTE is not supported, use DISKETTE instead
e) add missing THEN after IF
f) change PRINT #1,X,Y to WRITE #1,X,Y
g) add exit for autmated testing


The original programs came from here:
http://www.moorecad.com/classicbasic/

EOF
