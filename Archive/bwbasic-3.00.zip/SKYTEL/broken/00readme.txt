These programs:
1) use commands that are not supported by bwBASIC at this time, and/or
2) are not easy to test using the current  automated method, and/or
3) there are no plans to support graphics at this time.

EOF
