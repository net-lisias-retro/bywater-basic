/* This is for Borland Turbo C++ only: it requests the linker to
   establish a larger-than-usual stack of 8192 bytes for bwBASIC */

extern unsigned _stklen = 8192U;
