This folder tests features specfic to OPTION VERSION SYSTEM-360.
This folder contains example programs from the following references:

"BASIC Language Reference Manual"
by International Business Machines Corporation
(c) 1970, International Business Machines Corporation
http://bitsavers.org/pdf/ibm/360/os/tso/
GC28-6837-0_BASIC_Language_Ref_Man_Jun70.pdf

"IBM System/360 0S(TS0) ITF:BASIC Terminal User's Guide"
by International Business Machines Corporation
(c) 1971, International Business Machines Corporation
http://bitsavers.org/pdf/ibm/360/os/tso/
SC28-6840-0_TSO_ITF_BASIC_Terminal_UG_Apr71.pdf         

"CALL/360: BASIC Reference Handbook"
by International Business Machines Corporation
(c) 1970, The Service Bureau Corporation
http://bitsavers.trailing-edge.com/pdf/ibm/360/os/
call_360/CALL_360_BASIC_Reference_Handbook_1970.pdf
