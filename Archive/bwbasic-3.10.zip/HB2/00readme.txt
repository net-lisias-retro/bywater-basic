
This directory contains most of the tests from the following reference:
------------------------------------------------------------------
The BASIC Handbook: Encyclopedia of the BASIC Computer Language
	by David A. Lien
	2nd Edition
	(c) 1981, CompuSoft Publishing
	ISBN 0-932760-05-8
	480 pages
------------------------------------------------------------------
Some programs were adapted for Bywater BASIC by Howard Wulf, AF5NE.
------------------------------------------------------------------
EOF
