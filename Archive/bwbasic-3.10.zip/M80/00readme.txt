These programs appear to work, and are part of regression testing.

Changes made:
a) add missing semicolon/comma in PRINT statements
b) change array names so they were not identical to scalar variable names
c) add spaces around reserved words
d) CASSETTE is not supported, use DISKETTE instead
e) add missing THEN after IF
f) change PRINT #1,X,Y to WRITE #1,X,Y
g) add exit for autmated testing

These programs were downloaded from 
http://www.classiccmp.org/cpmarchives/cpm/Software/WalnutCD/cpm/basic/

EOF
